package codec

//go:generate bash prebuild.sh
